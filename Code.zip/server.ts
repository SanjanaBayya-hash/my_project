import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { runRuleBasedLogic, runAIOptimizedLogic, EnergyInputs } from "./src/utils/energyLogic";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Energy Simulation API
  app.post("/api/simulate", (req, res) => {
    const inputs: EnergyInputs = req.body;
    
    const ruleBased = runRuleBasedLogic(inputs);
    const aiOptimized = runAIOptimizedLogic(inputs);

    res.json({
      ruleBased,
      aiOptimized,
      timestamp: new Date().toISOString()
    });
  });

  // 24-Hour Simulation API
  app.post("/api/simulate-24h", (req, res) => {
    const baseInputs: EnergyInputs = req.body;
    const hourlyData: any[] = [];
    let currentBatteryLevelRule = baseInputs.batteryLevel;
    let currentBatteryLevelAI = baseInputs.batteryLevel;

    for (let h = 0; h < 24; h++) {
      const time = `${h.toString().padStart(2, '0')}:00`;
      const inputsRule: EnergyInputs = { ...baseInputs, time, batteryLevel: currentBatteryLevelRule };
      const inputsAI: EnergyInputs = { ...baseInputs, time, batteryLevel: currentBatteryLevelAI };

      const ruleResult = runRuleBasedLogic(inputsRule);
      const aiResult = runAIOptimizedLogic(inputsAI);

      // Update battery levels for next hour
      // batteryChange is in kW, assuming 1 hour duration, so it's kWh
      currentBatteryLevelRule = Math.max(0, Math.min(100, currentBatteryLevelRule + (ruleResult.batteryChange / baseInputs.batteryCapacity) * 100));
      currentBatteryLevelAI = Math.max(0, Math.min(100, currentBatteryLevelAI + (aiResult.batteryChange / baseInputs.batteryCapacity) * 100));

      hourlyData.push({
        time,
        ruleBased: { ...ruleResult, batteryLevel: currentBatteryLevelRule },
        aiOptimized: { ...aiResult, batteryLevel: currentBatteryLevelAI }
      });
    }

    res.json({ hourlyData });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
