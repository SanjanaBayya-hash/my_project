import { Dashboard } from './components/Dashboard';
import { ThemeProvider } from './context/ThemeContext';
import { ThemeToggle } from './components/ThemeToggle';

export default function App() {
  return (
    <ThemeProvider>
      <div className="min-h-screen transition-colors duration-300">
        <ThemeToggle />
        
        {/* Background Gradients */}
        <div className="fixed inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-emerald-500/10 dark:bg-emerald-500/5 blur-[120px] rounded-full" />
          <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-blue-500/10 dark:bg-blue-500/5 blur-[120px] rounded-full" />
        </div>

        <main className="relative z-10">
          <Dashboard />
        </main>

        <footer className="relative z-10 py-12 border-t border-black/5 dark:border-white/5 text-center">
          <p className="text-slate-500 dark:text-slate-400 text-sm font-mono tracking-widest uppercase">
            Intelligent Energy Optimization System &copy; 2026
          </p>
        </footer>
      </div>
    </ThemeProvider>
  );
}
