import React, { useState } from 'react';
import { Simulation3D } from './Simulation3D';
import { useTheme } from '../context/ThemeContext';
import { Sun, Battery, Home, Zap, Cloud, Thermometer, Clock, Play, Info, BarChart3, TrendingUp, IndianRupee, Cpu, Settings } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area, Legend } from 'recharts';

interface SimulationResult {
  predictedSolarOutput: number;
  decision: string;
  reasoning: string;
  batteryChange: number;
  gridUsage: number;
  cost: number;
  tariff: number;
}

interface ComparisonData {
  ruleBased: SimulationResult;
  aiOptimized: SimulationResult;
  timestamp: string;
}

interface HourlyData {
  time: string;
  ruleBased: SimulationResult & { batteryLevel: number };
  aiOptimized: SimulationResult & { batteryLevel: number };
}

export const Dashboard = () => {
  const [inputs, setInputs] = useState({
    weather: 'Sunny',
    time: '12:00',
    temperature: '25',
    solarCapacity: '5',
    batteryCapacity: '10',
    batteryLevel: '50',
    houseDemand: '2.5'
  });

  const [result, setResult] = useState<ComparisonData | null>(null);
  const [mode, setMode] = useState<'ruleBased' | 'aiOptimized'>('aiOptimized');
  const [hourlyData, setHourlyData] = useState<HourlyData[] | null>(null);
  const [loading, setLoading] = useState(false);
  const [loading24h, setLoading24h] = useState(false);

  const { theme } = useTheme();
  const activeResult = result ? result[mode] : null;

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setInputs(prev => ({ ...prev, [name]: value }));
  };

  const run24hSimulation = async () => {
    setLoading24h(true);
    try {
      const response = await fetch('/api/simulate-24h', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...inputs,
          temperature: parseFloat(inputs.temperature),
          solarCapacity: parseFloat(inputs.solarCapacity),
          batteryCapacity: parseFloat(inputs.batteryCapacity),
          batteryLevel: parseFloat(inputs.batteryLevel),
          houseDemand: parseFloat(inputs.houseDemand)
        })
      });
      const data = await response.json();
      setHourlyData(data.hourlyData);
    } catch (error) {
      console.error('24h Simulation failed:', error);
    } finally {
      setLoading24h(false);
    }
  };
  const runSimulation = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/simulate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...inputs,
          temperature: parseFloat(inputs.temperature),
          solarCapacity: parseFloat(inputs.solarCapacity),
          batteryCapacity: parseFloat(inputs.batteryCapacity),
          batteryLevel: parseFloat(inputs.batteryLevel),
          houseDemand: parseFloat(inputs.houseDemand)
        })
      });
      const data = await response.json();
      setResult(data);
    } catch (error) {
      console.error('Simulation failed:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-8">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h1 className="text-4xl font-black tracking-tight text-slate-800 dark:text-white">
            Intelligent Energy <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-cyan-500">Optimizer</span>
          </h1>
          <p className="text-slate-500 dark:text-slate-400 mt-2 font-medium">AI-driven real-time energy flow simulation and prediction.</p>
        </div>
        <div className="flex flex-wrap items-center gap-4">
          <div className="glass-panel p-1 rounded-2xl flex items-center shadow-lg">
            <button
              onClick={() => setMode('ruleBased')}
              className={`px-6 py-2.5 rounded-xl text-xs font-black tracking-widest transition-all duration-300 ${mode === 'ruleBased' ? 'bg-slate-800 dark:bg-slate-700 text-white shadow-xl scale-105' : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-200'}`}
            >
              RULE-BASED
            </button>
            <div className="w-px h-6 bg-slate-200 dark:bg-slate-700 mx-1" />
            <button
              onClick={() => setMode('aiOptimized')}
              className={`px-6 py-2.5 rounded-xl text-xs font-black tracking-widest transition-all duration-300 ${mode === 'aiOptimized' ? 'bg-emerald-500 text-white shadow-xl shadow-emerald-500/30 scale-105' : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-200'}`}
            >
              AI OPTIMIZED
            </button>
          </div>
          
          <button
            onClick={run24hSimulation}
            disabled={loading24h}
            className="btn-gradient-slate px-6 py-4 rounded-xl font-black text-xs tracking-widest flex items-center gap-2"
          >
            {loading24h ? (
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <BarChart3 className="w-5 h-5" />
            )}
            24H SIMULATION
          </button>

          <button
            onClick={runSimulation}
            disabled={loading}
            className="btn-gradient-emerald px-8 py-4 rounded-xl font-black text-xs tracking-widest flex items-center gap-2"
          >
            {loading ? (
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <Play className="w-5 h-5 fill-current" />
            )}
            RUN MANUAL
          </button>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Inputs Section */}
        <div className="lg:col-span-1 space-y-6">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="glass-panel rounded-2xl p-6 space-y-6 border-l-4 border-blue-500"
          >
            <h2 className="text-xl font-black text-slate-800 dark:text-white flex items-center gap-2 uppercase tracking-widest">
              <Info className="w-5 h-5 text-blue-500" />
              System Inputs
            </h2>
            
            <div className="space-y-4">
              <InputGroup 
                label="Weather Condition" 
                name="weather" 
                value={inputs.weather} 
                onChange={handleInputChange} 
                icon={<Cloud className="w-4 h-4" />}
                placeholder="e.g. Sunny, Cloudy, Rainy"
              />
              <InputGroup 
                label="Time of Day" 
                name="time" 
                value={inputs.time} 
                onChange={handleInputChange} 
                icon={<Clock className="w-4 h-4" />}
                placeholder="e.g. 14:30"
              />
              <InputGroup 
                label="Temperature (°C)" 
                name="temperature" 
                value={inputs.temperature} 
                onChange={handleInputChange} 
                icon={<Thermometer className="w-4 h-4" />}
                placeholder="e.g. 25"
              />
              <div className="grid grid-cols-2 gap-4">
                <InputGroup 
                  label="Solar (kW)" 
                  name="solarCapacity" 
                  value={inputs.solarCapacity} 
                  onChange={handleInputChange} 
                  icon={<Sun className="w-4 h-4" />}
                />
                <InputGroup 
                  label="Battery (kWh)" 
                  name="batteryCapacity" 
                  value={inputs.batteryCapacity} 
                  onChange={handleInputChange} 
                  icon={<Battery className="w-4 h-4" />}
                />
              </div>
              <InputGroup 
                label="Battery Level (%)" 
                name="batteryLevel" 
                value={inputs.batteryLevel} 
                onChange={handleInputChange} 
                icon={<Zap className="w-4 h-4" />}
              />
              <InputGroup 
                label="House Demand (kW)" 
                name="houseDemand" 
                value={inputs.houseDemand} 
                onChange={handleInputChange} 
                icon={<Home className="w-4 h-4" />}
              />
            </div>
          </motion.div>

          {activeResult && (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className={`glass-panel rounded-2xl p-6 space-y-4 border-l-4 ${mode === 'aiOptimized' ? 'neon-border-ai border-ai' : 'neon-border-grid border-blue-500'}`}
            >
              <h3 className={`${mode === 'aiOptimized' ? 'text-ai' : 'text-blue-500'} font-black flex items-center gap-2 uppercase tracking-widest text-xs`}>
                {mode === 'aiOptimized' ? <Cpu className="w-4 h-4" /> : <Settings className="w-4 h-4" />}
                {mode === 'aiOptimized' ? 'AI Decision Engine' : 'Rule-Based Engine'}
              </h3>
              <div className="text-3xl font-black text-slate-800 dark:text-white uppercase italic tracking-tighter">
                {activeResult.decision.replace(/_/g, ' ')}
              </div>
              <p className="text-slate-500 dark:text-slate-400 text-sm leading-relaxed font-medium">
                {activeResult.reasoning}
              </p>
              <div className="pt-4 border-t border-black/5 dark:border-white/5 grid grid-cols-2 gap-4">
                <div>
                  <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Tariff Rate</div>
                  <div className="text-lg font-black text-slate-800 dark:text-white">₹{activeResult.tariff}/kWh</div>
                </div>
                <div>
                  <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Current Cost</div>
                  <div className="text-lg font-black text-slate-800 dark:text-white">₹{activeResult.cost.toFixed(2)}</div>
                </div>
              </div>
            </motion.div>
          )}

          {result && (
            <PerformanceSummary 
              ruleBased={result.ruleBased} 
              aiOptimized={result.aiOptimized} 
            />
          )}
        </div>

        {/* Visualization Section */}
        <div className="lg:col-span-2 space-y-6">
          <Simulation3D 
            solarActive={activeResult ? activeResult.predictedSolarOutput > 0.1 : false}
            batteryLevel={parseFloat(inputs.batteryLevel)}
            gridActive={activeResult ? activeResult.gridUsage > 0 : false}
            flowToBattery={activeResult ? activeResult.decision === 'CHARGE_BATTERY' || activeResult.decision === 'CHARGE_FROM_GRID' : false}
            flowFromBattery={activeResult ? activeResult.decision === 'DISCHARGE_BATTERY' : false}
            flowToHouse={activeResult ? activeResult.predictedSolarOutput > 0.1 || activeResult.decision === 'DISCHARGE_BATTERY' || activeResult.gridUsage > 0 : false}
            flowFromGrid={activeResult ? activeResult.gridUsage > 0 || activeResult.decision === 'CHARGE_FROM_GRID' : false}
            weather={inputs.weather}
          />

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <StatCard 
              label="Solar Output" 
              value={activeResult ? `${activeResult.predictedSolarOutput.toFixed(2)} kW` : '--'} 
              icon={<Sun className="text-solar" />}
              neonClass="neon-border-solar"
            />
            <StatCard 
              label="Battery Flow" 
              value={activeResult ? `${activeResult.batteryChange > 0 ? '+' : ''}${activeResult.batteryChange.toFixed(2)} kW` : '--'} 
              icon={<Battery className="text-battery" />}
              neonClass="neon-border-battery"
            />
            <StatCard 
              label="Grid Usage" 
              value={activeResult ? `${activeResult.gridUsage.toFixed(2)} kW` : '--'} 
              icon={<Zap className="text-grid" />}
              neonClass="neon-border-grid"
            />
          </div>

          <AnimatePresence>
            {hourlyData && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="space-y-6 overflow-hidden"
              >
                <div className="glass-panel rounded-2xl p-6 border-l-4 border-emerald-500">
                  <h3 className="text-lg font-black text-slate-800 dark:text-white mb-6 flex items-center gap-2 uppercase tracking-widest">
                    <TrendingUp className="w-5 h-5 text-emerald-400" />
                    24-Hour Performance Trends
                  </h3>
                  <div className="h-[300px] w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={hourlyData}>
                        <defs>
                          <linearGradient id="colorSolar" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#fbbf24" stopOpacity={0.3}/>
                            <stop offset="95%" stopColor="#fbbf24" stopOpacity={0}/>
                          </linearGradient>
                          <linearGradient id="colorBattery" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                            <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" stroke={theme === 'dark' ? '#1e293b' : '#e2e8f0'} vertical={false} />
                        <XAxis dataKey="time" stroke="#64748b" fontSize={10} tickLine={false} axisLine={false} />
                        <YAxis stroke="#64748b" fontSize={10} tickLine={false} axisLine={false} />
                        <Tooltip 
                          contentStyle={{ backgroundColor: 'var(--card-bg)', border: '1px solid var(--card-border)', borderRadius: '12px', backdropFilter: 'blur(12px)' }}
                          itemStyle={{ fontSize: '12px' }}
                        />
                        <Legend />
                        <Area type="monotone" dataKey={`${mode}.predictedSolarOutput`} name="Solar Output (kW)" stroke="#fbbf24" fillOpacity={1} fill="url(#colorSolar)" />
                        <Area type="monotone" dataKey={`${mode}.batteryLevel`} name="Battery Level (%)" stroke="#10b981" fillOpacity={1} fill="url(#colorBattery)" />
                        <Line type="monotone" dataKey={`${mode}.gridUsage`} name="Grid Usage (kW)" stroke="#ef4444" dot={false} strokeWidth={2} />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};

const PerformanceSummary = ({ ruleBased, aiOptimized }: { ruleBased: SimulationResult, aiOptimized: SimulationResult }) => {
  const costSaving = ((ruleBased.cost - aiOptimized.cost) / (ruleBased.cost || 1)) * 100;
  const gridReduction = ((ruleBased.gridUsage - aiOptimized.gridUsage) / (ruleBased.gridUsage || 1)) * 100;

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="glass-panel rounded-2xl p-6 space-y-6 border-l-4 border-savings neon-border-savings"
    >
      <h3 className="text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase tracking-widest flex items-center gap-2">
        <TrendingUp className="w-4 h-4 text-savings" />
        Performance Summary
      </h3>
      
      <div className="grid grid-cols-1 gap-4">
        <div className="flex justify-between items-end">
          <div className="space-y-1">
            <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Cost Reduction</div>
            <div className="text-2xl font-black text-emerald-500">{Math.max(0, costSaving).toFixed(1)}%</div>
          </div>
          <div className="text-right space-y-1">
            <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Grid Reduction</div>
            <div className="text-2xl font-black text-blue-500">{Math.max(0, gridReduction).toFixed(1)}%</div>
          </div>
        </div>

        <div className="pt-4 border-t border-black/5 dark:border-white/5 flex items-center justify-center">
          <div className="bg-emerald-500/10 text-emerald-500 text-[10px] font-black px-2 py-1 rounded border border-emerald-500/20">
            TARGET: 8-12% SAVINGS
          </div>
        </div>
      </div>
    </motion.div>
  );
};

const InputGroup = ({ label, name, value, onChange, icon, placeholder }: any) => (
  <motion.div 
    whileHover={{ y: -2 }}
    className="space-y-2"
  >
    <label className="text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase tracking-widest flex items-center gap-2">
      <span className="p-1.5 rounded-md bg-slate-100 dark:bg-slate-800 text-blue-500 dark:text-blue-400 border border-black/5 dark:border-white/5">
        {icon}
      </span>
      {label}
    </label>
    <input
      type="text"
      name={name}
      value={value}
      onChange={onChange}
      placeholder={placeholder}
      className="w-full bg-white/50 dark:bg-slate-900/50 border border-black/5 dark:border-white/10 rounded-xl px-4 py-3 text-slate-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all font-mono text-sm"
    />
  </motion.div>
);

const StatCard = ({ label, value, icon, neonClass }: any) => (
  <motion.div 
    whileHover={{ scale: 1.02, y: -4 }}
    className={`glass-panel rounded-2xl p-5 flex items-center gap-4 border-l-4 ${neonClass}`}
  >
    <div className="p-3 bg-slate-100 dark:bg-slate-900 rounded-xl shadow-inner">
      {icon}
    </div>
    <div>
      <div className="text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase tracking-widest">{label}</div>
      <motion.div 
        key={value}
        initial={{ opacity: 0, x: -10 }}
        animate={{ opacity: 1, x: 0 }}
        className="text-xl font-bold text-slate-800 dark:text-white"
      >
        {value}
      </motion.div>
    </div>
  </motion.div>
);
