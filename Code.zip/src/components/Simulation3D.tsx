import React, { useRef, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, PerspectiveCamera, Text, Float, Stars, Cloud, Environment } from '@react-three/drei';
import * as THREE from 'three';
import { motion } from 'motion/react';

interface FlowProps {
  from: [number, number, number];
  to: [number, number, number];
  active: boolean;
  color: string;
  speed?: number;
}

const EnergyFlow = ({ from, to, active, color, speed = 1 }: FlowProps) => {
  const points = useMemo(() => {
    const curve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(...from),
      new THREE.Vector3((from[0] + to[0]) / 2, (from[1] + to[1]) / 2 + 0.5, (from[2] + to[2]) / 2),
      new THREE.Vector3(...to),
    ]);
    return curve.getPoints(50);
  }, [from, to]);

  const particles = useRef<THREE.Group>(null);

  useFrame((state) => {
    if (!active || !particles.current) return;
    const time = state.clock.getElapsedTime() * speed;
    particles.current.children.forEach((child, i) => {
      const t = (time + i / 5) % 1;
      const pos = new THREE.CatmullRomCurve3(points).getPointAt(t);
      child.position.copy(pos);
      child.scale.setScalar(active ? 1 : 0);
    });
  });

  return (
    <group ref={particles}>
      {active && Array.from({ length: 5 }).map((_, i) => (
        <mesh key={i}>
          <sphereGeometry args={[0.08, 8, 8]} />
          <meshBasicMaterial color={color} transparent opacity={0.8} />
        </mesh>
      ))}
      <line>
        <bufferGeometry attach="geometry" {...new THREE.BufferGeometry().setFromPoints(points)} />
        <lineBasicMaterial attach="material" color={color} transparent opacity={0.2} linewidth={1} />
      </line>
    </group>
  );
};

const SolarPanel = ({ active }: { active: boolean }) => (
  <group position={[-4, 0, -2]}>
    <mesh rotation={[-Math.PI / 4, 0, 0]}>
      <boxGeometry args={[2, 0.1, 1.5]} />
      <meshStandardMaterial color={active ? "#3b82f6" : "#1e293b"} metalness={0.8} roughness={0.2} />
    </mesh>
    <Text position={[0, 1.2, 0]} fontSize={0.3} color="white">Solar Array</Text>
  </group>
);

const House = () => (
  <group position={[0, 0, 0]}>
    {/* Base */}
    <mesh position={[0, 0.75, 0]}>
      <boxGeometry args={[2, 1.5, 2]} />
      <meshStandardMaterial color="#f8fafc" />
    </mesh>
    {/* Roof */}
    <mesh position={[0, 1.75, 0]} rotation={[0, Math.PI / 4, 0]}>
      <coneGeometry args={[1.8, 1, 4]} />
      <meshStandardMaterial color="#ef4444" />
    </mesh>
    <Text position={[0, 2.5, 0]} fontSize={0.4} color="white">Smart Home</Text>
  </group>
);

const Battery = ({ level }: { level: number }) => (
  <group position={[4, 0, -2]}>
    <mesh position={[0, 0.5, 0]}>
      <boxGeometry args={[1, 1, 1]} />
      <meshStandardMaterial color="#334155" />
    </mesh>
    {/* Charge Indicator */}
    <mesh position={[0, 0.5, 0.51]}>
      <planeGeometry args={[0.8, 0.8 * (level / 100)]} />
      <meshBasicMaterial color={level > 20 ? "#22c55e" : "#ef4444"} />
    </mesh>
    <Text position={[0, 1.2, 0]} fontSize={0.3} color="white">Battery ({level}%)</Text>
  </group>
);

const Grid = ({ active }: { active: boolean }) => (
  <group position={[0, 0, -5]}>
    <mesh position={[0, 1.5, 0]}>
      <boxGeometry args={[0.2, 3, 0.2]} />
      <meshStandardMaterial color="#475569" />
    </mesh>
    <mesh position={[0, 2.5, 0]}>
      <boxGeometry args={[2, 0.1, 0.1]} />
      <meshStandardMaterial color="#475569" />
    </mesh>
    {active && (
      <pointLight position={[0, 2.6, 0]} color="#fbbf24" intensity={2} distance={5} />
    )}
    <Text position={[0, 3.5, 0]} fontSize={0.3} color="white">Power Grid</Text>
  </group>
);

const PPOCircle = ({ active }: { active: boolean }) => {
  const meshRef = useRef<THREE.Mesh>(null);
  
  useFrame((state) => {
    if (!meshRef.current || !active) return;
    const s = 1 + Math.sin(state.clock.getElapsedTime() * 4) * 0.05;
    meshRef.current.scale.set(s, s, s);
  });

  return (
    <group position={[0, 0.05, 2.5]}>
      <mesh ref={meshRef} rotation={[-Math.PI / 2, 0, 0]}>
        <circleGeometry args={[0.8, 32]} />
        <meshBasicMaterial color={active ? "#3b82f6" : "#1e293b"} transparent opacity={0.6} />
      </mesh>
      <Text
        position={[0, 0.1, 0]}
        rotation={[-Math.PI / 2, 0, 0]}
        fontSize={0.3}
        color="white"
      >
        PPO
      </Text>
      {active && <pointLight position={[0, 0.5, 0]} color="#3b82f6" intensity={1} distance={3} />}
    </group>
  );
};

interface SimulationProps {
  solarActive: boolean;
  batteryLevel: number;
  gridActive: boolean;
  flowToBattery: boolean;
  flowFromBattery: boolean;
  flowToHouse: boolean;
  flowFromGrid: boolean;
  weather: string;
  ppoDecision?: string;
  ppoReward?: number;
}

export const Simulation3D = ({
  solarActive,
  batteryLevel,
  gridActive,
  flowToBattery,
  flowFromBattery,
  flowToHouse,
  flowFromGrid,
  weather,
  ppoDecision,
  ppoReward
}: SimulationProps) => {
  const isCloudy = weather.toLowerCase().includes('cloud') || weather.toLowerCase().includes('overcast');
  const isRaining = weather.toLowerCase().includes('rain');

  return (
    <div className="w-full h-[500px] bg-slate-900 rounded-2xl overflow-hidden shadow-2xl relative border border-white/10">
      <Canvas shadows>
        <PerspectiveCamera makeDefault position={[8, 8, 12]} fov={40} />
        <OrbitControls enablePan={false} maxPolarAngle={Math.PI / 2.1} />
        
        <ambientLight intensity={0.5} />
        <directionalLight position={[10, 10, 5]} intensity={1} castShadow />
        
        <Stars radius={100} depth={50} count={5000} factor={4} saturation={0} fade speed={1} />
        {isCloudy && <Cloud opacity={0.5} speed={0.4} position={[-5, 5, -5]} />}
        
        <Environment preset="city" />

        <SolarPanel active={solarActive} />
        <House />
        <Battery level={batteryLevel} />
        <Grid active={gridActive} />
        <PPOCircle active={!!ppoDecision} />

        {/* Energy Flows */}
        <EnergyFlow from={[-4, 0.5, -2]} to={[0, 1, 0]} active={flowToHouse} color="#fbbf24" speed={1.5} />
        <EnergyFlow from={[-4, 0.5, -2]} to={[4, 0.5, -2]} active={flowToBattery} color="#22c55e" speed={1.2} />
        <EnergyFlow from={[4, 0.5, -2]} to={[0, 1, 0]} active={flowFromBattery} color="#3b82f6" speed={1.2} />
        <EnergyFlow from={[0, 2.5, -5]} to={[0, 1, 0]} active={flowFromGrid} color="#ef4444" speed={1.5} />

        {/* Ground */}
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.1, 0]} receiveShadow>
          <planeGeometry args={[20, 20]} />
          <meshStandardMaterial color="#0f172a" />
        </mesh>
        <gridHelper args={[20, 20, "#1e293b", "#1e293b"]} position={[0, 0, 0]} />
      </Canvas>
      
      <div className="absolute top-4 left-4 bg-black/40 backdrop-blur-md p-3 rounded-lg border border-white/10 text-white text-xs uppercase tracking-widest font-mono">
        System Status: {solarActive ? 'Generating' : 'Idle'}
      </div>
    </div>
  );
};
