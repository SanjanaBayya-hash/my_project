export interface EnergyInputs {
  weather: string;
  time: string;
  temperature: number;
  solarCapacity: number;
  batteryCapacity: number;
  batteryLevel: number;
  houseDemand: number;
}

export interface SimulationResult {
  predictedSolarOutput: number;
  decision: string;
  reasoning: string;
  batteryChange: number;
  gridUsage: number;
  cost: number;
  tariff: number;
}

export const getTariff = (time: string): number => {
  const [hours] = time.split(':').map(Number);
  if (hours >= 18 && hours < 22) return 12; // Peak (6PM–10PM)
  if (hours >= 23 || hours < 6) return 5; // Off-peak (11PM–6AM)
  return 8; // Normal
};

export const calculateSolarOutput = (inputs: EnergyInputs): number => {
  const [hours, minutes] = inputs.time.split(':').map(Number);
  const timeInHours = hours + minutes / 60;
  
  // Peak solar is around 12:00 to 14:00
  const timeFactor = Math.max(0, 1 - Math.pow((timeInHours - 13) / 6, 2));
  
  let weatherFactor = 1.0;
  const lowerWeather = inputs.weather.toLowerCase();
  if (lowerWeather.includes('cloud') || lowerWeather.includes('overcast')) weatherFactor = 0.3;
  if (lowerWeather.includes('rain') || lowerWeather.includes('storm')) weatherFactor = 0.1;
  if (lowerWeather.includes('clear') || lowerWeather.includes('sun')) weatherFactor = 1.0;

  return inputs.solarCapacity * timeFactor * weatherFactor;
};

export const runRuleBasedLogic = (inputs: EnergyInputs): SimulationResult => {
  const predictedSolarOutput = calculateSolarOutput(inputs);
  const netEnergy = predictedSolarOutput - inputs.houseDemand;
  const tariff = getTariff(inputs.time);
  
  let decision = "IDLE";
  let reasoning = "";
  let batteryChange = 0;
  let gridUsage = 0;

  if (netEnergy > 0) {
    if (inputs.batteryLevel < 100) {
      decision = "CHARGE_BATTERY";
      batteryChange = Math.min(netEnergy, inputs.batteryCapacity * 0.2);
      reasoning = `Surplus energy of ${netEnergy.toFixed(2)} kW detected. Charging battery.`;
    } else {
      decision = "IDLE";
      reasoning = `Battery is full. Surplus energy of ${netEnergy.toFixed(2)} kW is available but not stored.`;
    }
  } else {
    const deficit = Math.abs(netEnergy);
    if (inputs.batteryLevel > 5) {
      decision = "DISCHARGE_BATTERY";
      batteryChange = -Math.min(deficit, inputs.batteryCapacity * 0.2);
      const remainingDeficit = deficit + batteryChange;
      if (remainingDeficit > 0.01) {
        gridUsage = remainingDeficit;
        reasoning = `Deficit of ${deficit.toFixed(2)} kW. Battery discharging. Remaining ${gridUsage.toFixed(2)} kW pulled from grid.`;
      } else {
        reasoning = `Deficit of ${deficit.toFixed(2)} kW. Battery discharging to cover full demand.`;
      }
    } else {
      decision = "USE_GRID";
      gridUsage = deficit;
      reasoning = `Deficit of ${deficit.toFixed(2)} kW. Battery is too low. Pulling from grid.`;
    }
  }

  const cost = gridUsage * tariff;

  return { predictedSolarOutput, decision, reasoning, batteryChange, gridUsage, cost, tariff };
};

export const runAIOptimizedLogic = (inputs: EnergyInputs): SimulationResult => {
  const predictedSolarOutput = calculateSolarOutput(inputs);
  const netEnergy = predictedSolarOutput - inputs.houseDemand;
  const tariff = getTariff(inputs.time);
  
  let decision = "IDLE";
  let reasoning = "";
  let batteryChange = 0;
  let gridUsage = 0;

  const isPeak = tariff === 12;
  const isOffPeak = tariff === 5;

  if (netEnergy > 0) {
    if (inputs.batteryLevel < 100) {
      decision = "CHARGE_BATTERY";
      batteryChange = Math.min(netEnergy, inputs.batteryCapacity * 0.2);
      reasoning = `AI: Surplus energy detected. Charging battery to save for peak hours.`;
    } else {
      decision = "IDLE";
      reasoning = `AI: Battery full. Surplus energy available.`;
    }
  } else {
    const deficit = Math.abs(netEnergy);
    if (isPeak && inputs.batteryLevel > 5) {
      // Prioritize discharging during peak
      decision = "DISCHARGE_BATTERY";
      batteryChange = -Math.min(deficit, inputs.batteryCapacity * 0.3); // Aggressive discharge during peak
      const remainingDeficit = deficit + batteryChange;
      gridUsage = Math.max(0, remainingDeficit);
      reasoning = `AI: Peak tariff detected (₹12/kWh). Prioritizing battery discharge to minimize grid cost.`;
    } else if (isOffPeak && inputs.batteryLevel < 80) {
      // Opportunistic charging during off-peak if battery is not full
      decision = "CHARGE_FROM_GRID";
      batteryChange = Math.min(inputs.batteryCapacity * 0.15, 80 - inputs.batteryLevel);
      gridUsage = deficit + batteryChange;
      reasoning = `AI: Off-peak tariff detected (₹5/kWh). Charging battery from grid to prepare for peak hours.`;
    } else if (inputs.batteryLevel > 10) {
      decision = "DISCHARGE_BATTERY";
      batteryChange = -Math.min(deficit, inputs.batteryCapacity * 0.2);
      const remainingDeficit = deficit + batteryChange;
      gridUsage = Math.max(0, remainingDeficit);
      reasoning = `AI: Normal tariff. Using battery to offset demand.`;
    } else {
      decision = "USE_GRID";
      gridUsage = deficit;
      reasoning = `AI: Battery low. Using grid power.`;
    }
  }

  const cost = gridUsage * tariff;

  return { predictedSolarOutput, decision, reasoning, batteryChange, gridUsage, cost, tariff };
};
